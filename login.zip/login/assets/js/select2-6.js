$(".js-example-placeholder-single").select2({
  placeholder: "Select a state",
  allowClear: true
});
 